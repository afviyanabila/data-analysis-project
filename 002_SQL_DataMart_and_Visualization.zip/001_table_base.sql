select 
	concat(pjl.id_invoice,'_',pjl.id_customer)as 'id_penjualan', #Identify primary key
	#Join data for data base
	pjl.tanggal, 
	pjl.id_invoice,
	pjl.id_barang,
	brg.nama_barang,
	pjl.harga,
	pjl.jumlah_barang,
	pjl.unit,
	pjl.jumlah_barang * pjl.harga as total_harga_barang,
	pjl.mata_uang,
	pjl.brand_id as id_brand,
	brg.lini as nama_brand,
	pjl.id_customer,
	plg.nama as nama_customer,
	plg.cabang_sales,
	pjl.id_distributor,
	plg.group_category
from datamart.penjualan pjl
left join datamart.barang brg
on pjl.id_barang = brg.kode_barang 
left join datamart.pelanggan plg 
on pjl.id_customer = plg.id_customer 
	
	
	