select
	id_invoice,
	tanggal,
	id_customer,
	nama_customer,
	cabang_sales,
	id_distributor,
	group_category,
	count(distinct id_barang) as total_barang,
	sum(total_harga_barang) as total_pembelian
from table_base tb
group by id_invoice, tanggal, id_customer, nama_customer,
	cabang_sales, id_distributor, group_category
order by id_invoice